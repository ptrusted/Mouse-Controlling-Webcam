﻿namespace WebcamInput
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.ImageBox = new AForge.Controls.VideoSourcePlayer();
            this.Status = new System.Windows.Forms.Label();
            this.TheTimer = new System.Windows.Forms.Timer(this.components);
            this.ButtonInfo = new System.Windows.Forms.Button();
            this.MouseSpeedSlider = new System.Windows.Forms.TrackBar();
            ((System.ComponentModel.ISupportInitialize)(this.MouseSpeedSlider)).BeginInit();
            this.SuspendLayout();
            // 
            // ImageBox
            // 
            this.ImageBox.AllowDrop = true;
            this.ImageBox.Location = new System.Drawing.Point(9, 2);
            this.ImageBox.Margin = new System.Windows.Forms.Padding(0);
            this.ImageBox.Name = "ImageBox";
            this.ImageBox.Size = new System.Drawing.Size(200, 150);
            this.ImageBox.TabIndex = 0;
            this.ImageBox.TabStop = false;
            this.ImageBox.VideoSource = null;
            this.ImageBox.NewFrame += new AForge.Controls.VideoSourcePlayer.NewFrameHandler(this.ImageBox_NewFrame);
            // 
            // Status
            // 
            this.Status.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.Status.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.Status.Location = new System.Drawing.Point(0, 228);
            this.Status.Name = "Status";
            this.Status.Size = new System.Drawing.Size(217, 13);
            this.Status.TabIndex = 1;
            this.Status.Text = "Status : ...";
            // 
            // TheTimer
            // 
            this.TheTimer.Enabled = true;
            this.TheTimer.Tick += new System.EventHandler(this.TheTimer_Tick);
            // 
            // ButtonInfo
            // 
            this.ButtonInfo.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ButtonInfo.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.ButtonInfo.ForeColor = System.Drawing.SystemColors.Info;
            this.ButtonInfo.Location = new System.Drawing.Point(0, 205);
            this.ButtonInfo.Name = "ButtonInfo";
            this.ButtonInfo.Size = new System.Drawing.Size(217, 23);
            this.ButtonInfo.TabIndex = 2;
            this.ButtonInfo.Text = "Info";
            this.ButtonInfo.UseVisualStyleBackColor = false;
            this.ButtonInfo.Click += new System.EventHandler(this.ButtonInfo_Click);
            // 
            // MouseSpeedSlider
            // 
            this.MouseSpeedSlider.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.MouseSpeedSlider.LargeChange = 1;
            this.MouseSpeedSlider.Location = new System.Drawing.Point(0, 160);
            this.MouseSpeedSlider.Maximum = 20;
            this.MouseSpeedSlider.Minimum = 5;
            this.MouseSpeedSlider.Name = "MouseSpeedSlider";
            this.MouseSpeedSlider.Size = new System.Drawing.Size(217, 45);
            this.MouseSpeedSlider.TabIndex = 3;
            this.MouseSpeedSlider.Value = 8;
            this.MouseSpeedSlider.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoValidate = System.Windows.Forms.AutoValidate.EnableAllowFocusChange;
            this.BackColor = System.Drawing.SystemColors.Desktop;
            this.ClientSize = new System.Drawing.Size(217, 241);
            this.Controls.Add(this.MouseSpeedSlider);
            this.Controls.Add(this.ButtonInfo);
            this.Controls.Add(this.Status);
            this.Controls.Add(this.ImageBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Opacity = 0.25D;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WebcamInput";
            this.TopMost = true;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_Exit);
            this.Load += new System.EventHandler(this.MainForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.MouseSpeedSlider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private AForge.Controls.VideoSourcePlayer ImageBox;
        private System.Windows.Forms.Label Status;
        private System.Windows.Forms.Timer TheTimer;
        private System.Windows.Forms.Button ButtonInfo;
        private System.Windows.Forms.TrackBar MouseSpeedSlider;
    }
}

