﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using AForge.Video.DirectShow;

namespace WebcamInput
{
    public partial class CameraSelection : Form
    {
        private FilterInfoCollection DetectedCameraDevices;
        public string SelectedCamera;

        public CameraSelection()
        {
            InitializeComponent();
        }


        private void CameraSelection_Load(object sender, EventArgs e)
        {
            EnumerateCameraDevices();
        }

        private void EnumerateCameraDevices ()
        {
            ButtonOk.Enabled = false;
            try
            {
                // Enumerate video devices.
                DetectedCameraDevices = new FilterInfoCollection(FilterCategory.VideoInputDevice);
                if (DetectedCameraDevices.Count == 0)
                    throw new ApplicationException();
                foreach (FilterInfo cameraItem in DetectedCameraDevices)
                    ComboBoxCamera.Items.Add(cameraItem.Name);
            } catch (ApplicationException e)
            {
                ComboBoxCamera.Items.Add("I'm sorry, no camera detected !");
                ComboBoxCamera.Enabled = false;
                ButtonOk.Enabled = false;
            }
        }

        private void ComboBoxCamera_SelectedIndexChanged(object sender, EventArgs e)
        {
            ButtonOk.Enabled = true;
        }

        private void ButtonOk_Click(object sender, EventArgs e)
        {
            SelectedCamera = DetectedCameraDevices[ComboBoxCamera.SelectedIndex].MonikerString;
            
        }

    }
}
