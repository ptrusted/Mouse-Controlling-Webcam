﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Windows.Forms;

using AForge.Video;
using AForge.Video.DirectShow;

/// <summary>
/// Iman, October 2017.
/// ptrusted@gmail.com.
/// </summary>
namespace WebcamInput
{
    public partial class MainForm : Form
    {
        // ====================================================================
        // PUBLIC VARIABLES

        /// <summary>
        /// Keeps the previous image's colors obtained from camera.
        /// </summary>
        public Color[,] PreviousImage;
        /// <summary>
        /// The subtraction result of current and previous image.
        /// </summary>
        public Color[,] SubtractionResult;
        /// <summary>
        /// Polarization result of boosted colors.
        /// </summary>
        public Color[,] PolarizationResult;
        /// <summary>
        /// The length of area in the center of image to be processed.
        /// </summary>
        public int AreaToProcess;
        /// <summary>
        /// The minimum pixel area allowed to say that this is a white object (value should be square).
        /// </summary>
        public int MinimumWhitePixel;
        /// <summary>
        /// Mouse moving states.
        /// </summary>
        bool[] MOUSE_IS_MOVING;
        /// <summary>
        /// Mouse left clicked state.
        /// </summary>
        bool[] MOUSE_IS_CLICKED;
        /// <summary>
        /// Mouse left click timer when it reaches zero, the event will be called.
        /// </summary>
        int MouseLeftClickTimer;
        /// <summary>
        /// Mouse right click timer when it reaches zero, the event will be called.
        /// </summary>
        int MouseRightClickTimer;
        /// <summary>
        /// Amount of click done by user.
        /// </summary>
        int MouseLeftClickCounter;
        /// <summary>
        /// Amount of click done by user.
        /// </summary>
        int MouseRightClickCounter;
        /// <summary>
        /// Constant value of how fast mouse will move.
        /// </summary>
        public int MouseSpeed;
        /// <summary>
        /// Mouse movement velocity in horizontal movement direction, will be decreased over time.
        /// </summary>
        float MouseHorizontalVelocity;
        /// <summary>
        /// Mouse movement velocity in vertical movement direction, will be decreased over time.
        /// </summary>
        float MouseVerticalVelocity;
        /// <summary>
        /// Mouse movement acceleration.
        /// </summary>
        float MouseAcceleration;

        // ====================================================================
        // MAIN FUNCTIONS

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            // Initialize variables.
            AreaToProcess = 20;
            MinimumWhitePixel = (int)(AreaToProcess );
            MOUSE_IS_CLICKED = new bool[2] { false, false };
            MOUSE_IS_MOVING = new bool[4] { false, false, false, false };
            MouseLeftClickTimer = MouseRightClickTimer = 3000;
            MouseLeftClickCounter = MouseRightClickCounter = 0;
            MouseSpeed = MouseSpeedSlider.Value * 2;
            MouseHorizontalVelocity = MouseVerticalVelocity = 0;
            MouseAcceleration = 0.25f;
            // Open camera device.
            OpenLocalCamera();
        }

        private void MainForm_Exit(object sender, EventArgs e)
        {
            // Close previous video source.
            ImageBox.SignalToStop();
            ImageBox.WaitForStop();
        }

        private void TheTimer_Tick(object sender, EventArgs e)
        {
            // Calling mouse controller every 100 milliseconds.
            ControlMouse();
        }

        // ====================================================================
        // AFORGE.NET RELATED AND IMAGE PROCESSING FUNCTIONS

        /// <summary>
        /// Update status text value.
        /// </summary>
        /// <param name="status"></param>
        private void UpdateStatus(string stts)
        {
            if(Status.InvokeRequired)
            {
                Status.Invoke(new MethodInvoker(delegate { Status.Text = "Status : " + stts; }));
            } else
                Status.Text = "Status : " + stts;
        }

        /// <summary>
        /// Show info dialog.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ButtonInfo_Click(object sender, EventArgs e)
        {
            AboutBox info = new AboutBox();
            info.ShowDialog();
        }

        /// <summary>
        /// Open detected local camera.
        /// </summary>
        private void OpenLocalCamera()
        {
            // Show camera selection form.
            CameraSelection cameraSelection = new CameraSelection();
            if(cameraSelection.ShowDialog(this) == DialogResult.OK)
            {
                // Create video source from selected camera.
                VideoCaptureDevice theCamera = new VideoCaptureDevice(cameraSelection.SelectedCamera);
                // Close previous video source.
                ImageBox.SignalToStop();
                ImageBox.WaitForStop();
                // Choose the smallest video resolution as possible.
                int min = 2048;
                int minIndex = 0;
                for (int a = 0; a < theCamera.VideoCapabilities.Length; a++)
                {
                    if (min > theCamera.VideoCapabilities[a].FrameSize.Width)
                    {
                        min = theCamera.VideoCapabilities[a].FrameSize.Width;
                        minIndex = a;
                    }
                }
                theCamera.VideoResolution = theCamera.VideoCapabilities[minIndex];                
                // Initialize variables that depend on camera frame size.
                int wdth = theCamera.VideoCapabilities[minIndex].FrameSize.Width;
                int hght = theCamera.VideoCapabilities[minIndex].FrameSize.Height;
                PreviousImage = new Color[wdth, hght];
                SubtractionResult = new Color[wdth, hght];
                PolarizationResult = new Color[wdth, hght];
                UpdateStatus("Frame size " + wdth.ToString() + " x " + hght.ToString());
                // Set the new video source.
                ImageBox.VideoSource = theCamera;
                ImageBox.Start();
                // Start update.
                TheTimer.Start();
            }
        }

        /// <summary>
        /// Processing image from camera.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="image"></param>
        private void ImageBox_NewFrame(object sender, ref Bitmap image)
        {
            // Center left point of image.
            Point leftCenterPoint = new Point(0, image.Height / 2);
            // Center right point of image.
            Point rightCenterPoint = new Point(image.Width, image.Height / 2);
            // Top center point of image.
            Point topCenterPoint = new Point(image.Width / 2, 0);
            // Bottom center point of image.
            Point bottomCenterPoint = new Point(image.Width / 2, image.Height);
            // Bottom center point of image.
            Point centerLeftPoint = new Point(image.Width / 4, image.Height / 2);
            // Bottom right point of image.
            Point centerRightPoint = new Point(image.Width * 3 / 4, image.Height / 2);
            // Total white point detected for all 6 areas.
            int[] totalWhiteDetected1 = new int[4] { 0, 0, 0, 0};
            int[] totalWhiteDetected2 = new int[2] { 0, 0 };

            // For each pixel in left center area.
            totalWhiteDetected1[0] = ProcessImageInArea(ref image,
                leftCenterPoint.X, leftCenterPoint.X + (AreaToProcess / 4),
                leftCenterPoint.Y - (AreaToProcess * 2), leftCenterPoint.Y + (AreaToProcess * 2));
            // For each pixel in right center area.
            totalWhiteDetected1[1] = ProcessImageInArea(ref image,
                rightCenterPoint.X - (AreaToProcess / 4), rightCenterPoint.X,
                rightCenterPoint.Y - (AreaToProcess * 2), rightCenterPoint.Y + (AreaToProcess * 2));
            // For each pixel in top center area.
            totalWhiteDetected1[2] = ProcessImageInArea(ref image,
                topCenterPoint.X - (AreaToProcess * 2), topCenterPoint.X + (AreaToProcess * 2),
                topCenterPoint.Y, topCenterPoint.Y + (AreaToProcess / 4));
            // For each pixel in bottom center area.
            totalWhiteDetected1[3] = ProcessImageInArea(ref image,
                bottomCenterPoint.X - (AreaToProcess * 2), bottomCenterPoint.X + (AreaToProcess * 2),
                bottomCenterPoint.Y - (AreaToProcess / 4), bottomCenterPoint.Y);
            // For each pixel in center right area.
            totalWhiteDetected2[0] = ProcessImageInArea(ref image,
                centerRightPoint.X - (AreaToProcess / 2), centerRightPoint.X + (AreaToProcess / 2),
                centerRightPoint.Y - (AreaToProcess / 2), centerRightPoint.Y + (AreaToProcess / 2)); ;
            // For each pixel in center left area.
            totalWhiteDetected2[1] = ProcessImageInArea(ref image,
                centerLeftPoint.X - (AreaToProcess / 2), centerLeftPoint.X + (AreaToProcess / 2),
                centerLeftPoint.Y - (AreaToProcess / 2), centerLeftPoint.Y + (AreaToProcess / 2));

            // Check total white point for each area and switch moving states.
            for (int a = 0; a < 4; a++)
            {
                if (totalWhiteDetected1[a] > MinimumWhitePixel)
                    MOUSE_IS_MOVING[a] = true;
                else
                    MOUSE_IS_MOVING[a] = false;
            }

            // Check total white point and switch button click states.
            for (int a = 0; a < 2; a++)
            {
                if (totalWhiteDetected2[a] > MinimumWhitePixel)
                    MOUSE_IS_CLICKED[a] = true;
                else
                    MOUSE_IS_CLICKED[a] = false;
            }
        }

        /// <summary>
        /// Processing image in specific area and return the total white points.
        /// </summary>
        private int ProcessImageInArea (ref Bitmap image,int minA,int maxA,int minB,int maxB)
        {
            int totalWhiteDetected = 0;
            for (int a = minA; a < maxA; a++)
            {
                for (int b = minB; b < maxB; b++)
                {
                    // Get the subtracted color.
                    // -------------------------------------------------------------------------------
                    SubtractionResult[a, b] = Color.FromArgb
                    (
                        255,
                        Math.Abs(image.GetPixel(a, b).R - PreviousImage[a, b].R),
                        Math.Abs(image.GetPixel(a, b).G - PreviousImage[a, b].G),
                        Math.Abs(image.GetPixel(a, b).B - PreviousImage[a, b].B)
                    );

                    // Get the highest value between R, G, and B.
                    // -------------------------------------------------------------------------------
                    int highestValue = Math.Max(Math.Max(
                        SubtractionResult[a, b].R, SubtractionResult[a, b].G),
                        SubtractionResult[a, b].B);

                    // Get the polarized color.
                    // -------------------------------------------------------------------------------
                    if (highestValue > 64)
                    {
                        // Set it to white.
                        PolarizationResult[a, b] = Color.White;
                        // Increase counter.
                        totalWhiteDetected++;
                    }
                    else
                        // Set it to black.
                        PolarizationResult[a, b] = Color.Black;

                    // Save current color.
                    // -------------------------------------------------------------------------------
                    PreviousImage[a, b] = image.GetPixel(a, b);

                    // Apply results into bitmap and mirror it.
                    // -------------------------------------------------------------------------------
                    image.SetPixel(a, b, PolarizationResult[a, b]);
                }
            }
            return totalWhiteDetected;
        }

        // ====================================================================
        // MOUSE EVENT RELATED FUNCTIONS

        /// <summary>
        /// To handle mouse event.
        /// </summary>
        [DllImport("user32.dll")] static extern void mouse_event(uint dwFlags, int dx, int dy, uint dwData, int dwExtraInfo);

        [Flags]
        private enum MouseFlags
        {
            MOUSEEVENTF_ABSOLUTE = 0x8000,
            MOUSEEVENTF_LEFTDOWN = 0x0002,
            MOUSEEVENTF_LEFTUP = 0x0004,
            MOUSEEVENTF_MIDDLEDOWN = 0x0020,
            MOUSEEVENTF_MIDDLEUP = 0x0040,
            MOUSEEVENTF_MOVE = 0x0001,
            MOUSEEVENTF_RIGHTDOWN = 0x0008,
            MOUSEEVENTF_RIGHTUP = 0x0010,
            MOUSEEVENTF_XDOWN = 0x0080,
            MOUSEEVENTF_XUP = 0x0100,
            MOUSEEVENTF_WHEEL = 0x0800,
            MOUSEEVENTF_HWHEEL = 0x01000
        }

        /// <summary>
        /// Calculate the distance between two points.
        /// Minus return value means left or up, otherwise means right or down.
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        private double GetDistanceAndDirection (Point a, Point b)
        {
            double deltaX = (double)(a.X - b.X);
            double deltaY = (double)(a.Y - b.Y);
            double dstnc;
            dstnc = Math.Sqrt((deltaX * deltaX) + (deltaY * deltaY));
            if(deltaX < 0 || deltaY < 0)
                return -dstnc;
            else
                return dstnc;
        }

        /// <summary>
        /// Switch points value into mouse states.
        /// </summary>
        /// <param name="currentA"></param>
        /// <param name="prevA"></param>
        /// <param name="currentB"></param>
        /// <param name="prevB"></param>
        private void ControlMouse ()
        {
            if (MOUSE_IS_MOVING[0])
            {
                if (MouseHorizontalVelocity >= 0)
                    MouseHorizontalVelocity += MouseAcceleration;
                else
                    MouseHorizontalVelocity = 0f;
            }
            if (MOUSE_IS_MOVING[1])
            {
                if (MouseHorizontalVelocity <= 0)
                    MouseHorizontalVelocity -= MouseAcceleration;
                else
                    MouseHorizontalVelocity = 0f;
            }
            if (MOUSE_IS_MOVING[2])
            {
                if (MouseVerticalVelocity <= 0)
                    MouseVerticalVelocity -= MouseAcceleration;
                else
                    MouseVerticalVelocity = 0f;
            }
            if (MOUSE_IS_MOVING[3])
            {
                if (MouseVerticalVelocity >= 0)
                    MouseVerticalVelocity += MouseAcceleration;
                else
                    MouseVerticalVelocity = 0;
            }

            // Handle mouse moving event.
            mouse_event(
                (int)MouseFlags.MOUSEEVENTF_MOVE,
                (int)(MouseSpeed * MouseHorizontalVelocity),
                (int)(MouseSpeed * MouseVerticalVelocity),
                0, 0);

            // Decrease mouse velocity so it moves smoothly.
            if (MouseHorizontalVelocity > 0.11f)
                MouseHorizontalVelocity -= 0.1f;
            else
            {
                if (MouseHorizontalVelocity < -0.11f)
                    MouseHorizontalVelocity += 0.1f;
                else
                    MouseHorizontalVelocity = 0f;
            }

            // Decrease mouse velocity so it moves smoothly.
            if (MouseVerticalVelocity > 0.11f)
                MouseVerticalVelocity -= 0.1f;
            else
            {
                if (MouseVerticalVelocity < -0.11f)
                    MouseVerticalVelocity += 0.1f;
                else
                    MouseVerticalVelocity = 0f;
            }

            // Mouse left click.
            if (MOUSE_IS_CLICKED[0])
            {
                if (MouseLeftClickCounter > 6 && MouseLeftClickTimer > 0)
                {
                    // Left click down event.
                    mouse_event((int)MouseFlags.MOUSEEVENTF_LEFTDOWN,
                        Cursor.Position.X, Cursor.Position.Y, 0, 0);
                    // Left click up event.
                    mouse_event((int)MouseFlags.MOUSEEVENTF_LEFTUP,
                        Cursor.Position.X, Cursor.Position.Y, 0, 0);
                    // Reset timer.
                    MouseLeftClickCounter = 0;
                }
                else
                {
                    if (MouseLeftClickTimer > 0)
                        MouseLeftClickCounter++;
                    else
                    {
                        // Reset click counter.
                        MouseLeftClickCounter = 0;
                        // Reset mouse click timer.
                        MouseLeftClickTimer = 2000;
                    }
                }
            }

            // Mouse right click.
            if (MOUSE_IS_CLICKED[1])
            {
                if (MouseRightClickCounter > 6 && MouseRightClickTimer > 0)
                {
                    // Left click down event.
                    mouse_event((int)MouseFlags.MOUSEEVENTF_RIGHTDOWN,
                        Cursor.Position.X, Cursor.Position.Y, 0, 0);
                    // Left click up event.
                    mouse_event((int)MouseFlags.MOUSEEVENTF_RIGHTUP,
                        Cursor.Position.X, Cursor.Position.Y, 0, 0);
                    // Reset timer.
                    MouseRightClickCounter = 0;
                }
                else
                {
                    if (MouseRightClickTimer > 0)
                        MouseRightClickCounter++;
                    else
                    {
                        // Reset click counter.
                        MouseRightClickCounter = 0;
                        // Reset mouse click timer.
                        MouseRightClickTimer = 2000;
                    }
                }
            }

            if (MouseLeftClickTimer > 0)
                // Decrease timer value every 100 miliseconds
                MouseLeftClickTimer -= TheTimer.Interval;

            if (MouseRightClickTimer > 0)
                // Decrease timer value every 100 miliseconds
                MouseRightClickTimer -= TheTimer.Interval;
        }

        /// <summary>
        /// To change mouse speed.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            MouseSpeed = MouseSpeedSlider.Value * 2;
        }
    }
}